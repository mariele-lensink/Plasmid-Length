#!/usr/bin/env python
from plasmidsizeselector.plasmidsizeselector import main
