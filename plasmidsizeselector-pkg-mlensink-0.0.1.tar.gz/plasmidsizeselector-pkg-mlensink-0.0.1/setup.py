import setuptools

with open("README.md", "r") as fh:
	long_description = fh.read()

setuptools.setup(
	name = "plasmidsizeselector-pkg-mlensink",
	version = "0.0.1",
	author = "Mariele Lensink",
	author_email = "marielelensink325@gmail.com",
	description = "selects out reads of estimated plasmid size length",
	long_description = long_description,
	long_description_content_type = "text/markdown",
	packages = ['plasmidsizeselector'],
	entry_points = {'console_scripts': ['plasmidsizeselector=plasmidsizeselector.plasmidsizeselector:main']}
)
