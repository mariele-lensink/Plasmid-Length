#!/usr/bin/env python

def makePlot(lenlist):
	print(" Using makePlot")
	import numpy as np
	import matplotlib.pyplot as plt 
	#bin each read length 
	#output is an array of length frequency (counts) and an array of the bin edges
	lengthArray = np.array(lenlist)
	counts,edges = list(np.histogram(lengthArray,1000))
	plt.hist(lengthArray, bins = 'auto')
	plt.show()
	#creates an array with the bin number of each length, indexes correspond to lengthlist
	indexList = list(np.digitize(lengthArray,edges))
	return edges, indexList, counts

def otsu(counts,lenlist,edges):
	import numpy as np
	print("using otsu")
	total = sum(counts)
	sumB = 0
	wB = 0
	maximum = 0.0
	sum1 = np.dot(edges, counts)
	for ii in range(len(counts)):
		wB = wB + counts[ii]
		wF = total - wB
		if wB == 0 or wF == 0:
			break
		sumB = sumB + edges[ii]*counts[ii]
		mF = (sum1 - sumB)/wF
		between = wB * wF * ((sumB/wB)-mF)*((sumB/wB)-mF)
		if between >= maximum:
			threshValue = edges[ii]
			maximum = between
	return maximum, threshValue

def distributionSeperator(threshValue,lenlist):
	print("using distributionSeparator")
	longLengths = []
	for i in range(len(lenlist)):
		if lenlist[i] > threshValue:
			longLengths.append(lenlist[i])
	return longLengths

def selectBin(counts):
	print("using selectBin")
	binMaximum = max(counts)
	countsList = list(counts)
	index = countsList.index(binMaximum)+1
	return binMaximum,index

def main():

	from Bio import SeqIO
	import numpy as np
	import matplotlib.pyplot as plt
	import collections
	import argparse

	parser = argparse.ArgumentParser(prog = "plasmidsizeselector.py")
	parser.add_argument("--inFile", dest= 'inFile', required = True)
	parser.add_argument("--outFile", dest = 'outFile', required = True)
	parser.add_argument("-s","--stats", action = 'store_true',dest = 'stats', required = False)
	args = parser.parse_args()

	seqlendict = {}
	fileName = args.inFile
	outFileName = args.outFile
	#read in each read as a record object
	for record in SeqIO.parse(fileName,"fastq"):
		#build a dictionary where keys = sequece ID (unique) and values = read length
		seqlendict.update({record.id:len(record.seq)})
	#make list of read lengths because numpy doesn't accept a dictionary view 
	lengthlist = list(seqlendict.values())

	bin_edges, binList, histCounts = makePlot(lengthlist)
	print("finished plot 1")
	
	if args.stats == True:
		maxval, threshold = otsu(histCounts, lengthlist, bin_edges[0:-1])
		print("finished otsu")
		newLengthList = distributionSeperator(threshold,lengthlist)
		print("finished distributionSeperator")
		bin_edges,binList,histCounts = makePlot(newLengthList)
		print("Finished plot 2")

	binMax, binIndex = selectBin(histCounts)
	print("finished selectBin")
	#make a sublist of indexes from a particular bin number
	binIndexSubList = []
	for i in range(len(binList)):
		binNum = binList[i]
		if binIndex == binNum:
			binIndexSubList.append(i)

	#make a set of lengths corresponding to bin number sub list
	lengthSubSet = set()
	for indexNum in binIndexSubList:
		lengthAdd = lengthlist[indexNum]
		lengthSubSet.add(lengthAdd)

	#get list of sequence ID's to be used in alignment
	IDList = []
	#iterate through the subset of lengths
	for setLength in lengthSubSet:
		#if subset length and dictionary length match, add the corresponding sequence ID to the list
		for ID, dictLength in seqlendict.items():
			if setLength == dictLength:
				IDList.append(ID)

	from Bio import SeqIO
	qualityList = [] 
	for record in SeqIO.parse(fileName, "fastq"):
		if np.mean(record.letter_annotations["phred_quality"])>=14:
			for ID in IDList:
				if record.id == ID:
					qualityList.append(record.id)
	outsequences = open(outFileName,"w")
	for record in SeqIO.parse(fileName,"fastq"):
		for ID in IDList:
			if ID == record.id:
				outsequences.write(">" + ID + "\n" + str(record.seq) + "\n")
	outsequences.close()
	return

if __name__ == "__main__":
	main()
