#!/usr/bin/env python

from Bio import SeqIO
import numpy as np
import matplotlib.pyplot as plt
import collections
import argparse
import gzip

#This function takes in a list of the lengths of each read, and makes a histogram of them according to count
##Defaults is 1000 bins
# 3 different outputs
##edges is the array of bin edges (only needed for otsu function if the stats option is chosen)
##indexList is a list of bin numbers that corresponds to the lengths list. In other words, if you were to line the two lists up, you would see the length of a read and the corresponding bin number that it is placed in.
##counts is the number of reads in each bin, this is the list that displays the distribution of read lengths in the histogram
def makePlot(lenlist):
	#bin each read length 
	#output is an array of length frequency (counts) and an array of the bin edges
	lengthArray = np.array(lenlist)
	counts,edges = list(np.histogram(lengthArray,1000))
	plt.hist(lengthArray, bins = 'auto')
	plt.show()
	#creates an array with the bin number of each length, indexes correspond to lengthlist
	indexList = list(np.digitize(lengthArray,edges))
	return edges, indexList, counts

#this function is only used if the stats option (-s) is written in the command line
#this takes the counts and edges outputs from make plot to calculate the threshold value in the bimodal distribution of read lengths.
def otsu(counts,lenlist,edges):
	total = sum(counts)
	sumB = 0
	wB = 0
	maximum = 0.0
	sum1 = np.dot(edges, counts)
	for ii in range(len(counts)):
		wB = wB + counts[ii]
		wF = total - wB
		if wB == 0 or wF == 0:
			break
		sumB = sumB + edges[ii]*counts[ii]
		mF = (sum1 - sumB)/wF
		between = wB * wF * ((sumB/wB)-mF)*((sumB/wB)-mF)
		if between >= maximum:
			threshValue = edges[ii]
			maximum = between
	return maximum, threshValue

#this function is only used if the stats option (-s) is written in the command line
#takes the threshold value found by the otsu function and iterates through the list of read lengths
#if the read length is bigger then the threshold value, it appends it to a new list of lengths
def distributionSeperator(threshValue,lenlist):
	longLengths = []
	for i in range(len(lenlist)):
		if lenlist[i] > threshValue:
			longLengths.append(lenlist[i])
	return longLengths

##this looks for the bin number with the greatest number of read lengths
##can be used without otsu method (default setting) if sequencing data is high quality (meaning that the bin with the greatest number of reads is the lengths of the actual plasmid size)
def selectBin(counts):
	binMaximum = max(counts)
	countsList = list(counts)
	index = countsList.index(binMaximum)+1
	return binMaximum,index

def main():

	

	parser = argparse.ArgumentParser(prog = "plasmidsizeselector.py")
	#write the path to the file you want to input
	parser.add_argument("--inFile", dest= 'inFile', required = True)
	#write the name of your output file
	parser.add_argument("--outFile", dest = 'outFile', required = True)
	#use the (-s) option if you have more short length reads than reads that are the length of the plasmid. (if the first peak is larger than the second in a bimodal distribution)
	parser.add_argument("-s","--stats", action = 'store_true',dest = 'stats', required = False)
	#use this option if you want to filter out reads that dont have an average phred score above 14
	parser.add_argument("-q","--quality", action = 'store_true', dest = 'quality', required = False)
	parser.add_argument("-b", "--bins", dest = "bins", nargs = "?", const = 1, type = int, default = 1)
	args = parser.parse_args()
	seqlendict = {}
	fileName = args.inFile
	outFileName = args.outFile
	
	if fileName.endswith(".gz"):
		with gzip.open(fileName) as handle:
			for record in SeqIO.parse(handle, "fastq"):
				seqlendict.update({record.id:len(record.seq)})
	
		#read in each read as a record object
	else:
		handle = fileName
		for record in SeqIO.parse(handle,"fastq"):
			#build a dictionary where keys = sequece ID (unique) and values = read length
			seqlendict.update({record.id:len(record.seq)})
	#make list of read lengths because numpy doesn't accept a dictionary view 
	lengthlist = list(seqlendict.values())
	
	#use makeplot function (see function above)
	bin_edges, binList, histCounts = makePlot(lengthlist)
	
	#when distribution is not ideal, run this (see functions above)
	if args.stats == True:
		maxval, threshold = otsu(histCounts, lengthlist, bin_edges[0:-1])
		newLengthList = distributionSeperator(threshold,lengthlist)
		bin_edges,binList,histCounts = makePlot(newLengthList)
	
	#both methods (with or without -s option) will output a list called histCounts, but the content has changed
	binMax, binIndex = selectBin(histCounts)
	
	#make a sublist of indexes from a particular bin number
	binIndexSubList = []
	for i in range(len(binList)):
		binNum = binList[i]
		if binIndex == binNum:
			binIndexSubList.append(i)

	#make a set of lengths corresponding to bin number sub list
	lengthSubSet = set()
	for indexNum in binIndexSubList:
		lengthAdd = lengthlist[indexNum]
		#we need a set because we are going to use this to iterate through a dictionary, we dont want to iterate through more than once for the same length because then we will have duplicate records
		lengthSubSet.add(lengthAdd)

	#get list of sequence ID's to be used in alignment
	IDList = []
	#iterate through the subset of lengths
	for setLength in lengthSubSet:
		#if subset length and dictionary length match, add the corresponding sequence ID to the list
		for ID, dictLength in seqlendict.items():
			if setLength == dictLength:
				IDList.append(ID)
	
	#opens the output file to be written into
	outsequences = open(outFileName,"w")
	#if qualtiy option is chosen, before writing, all of the reads with an average phred score under 14 will be filtered out
	if args.quality == True:
		qualityList = [] 
		for record in SeqIO.parse(handle, "fastq"):
			if np.mean(record.letter_annotations["phred_quality"])>=14:
				for ID in IDList:
					if record.id == ID:
						qualityList.append(record.id)
		#iterate through input file, if the record ID matches one in the list of IDs created, write it to the output file
		for record in SeqIO.parse(handle,"fastq"):
			for ID in qualityList:
				if ID == record.id:
					outsequences.write(record.format("fastq"))
	#if quality option isnt chosen, the reads arent filtered and a fastq file is written using the list of ID's and iterating through the input file
	else:
		for record in SeqIO.parse(handle,"fastq"):
			for ID in IDList:
				if ID == record.id:
					outsequences.write(record.format("fastq"))
	outsequences.close()
	return

if __name__ == "__main__":
	main()
